/**
*
* File: EscobarAsst02.cpp
* Purpose: Demonstrate ability to use VC++ and submit results
*
* Project: CSIS 2100 Assignment 02
* Company: Nova Southeastern University
* Supervisor: Dr. Michael Van Hilst
*
* Author: Rodrigo Escobar
* History: Created September 06 2012
* Assisted by: None
* References: Book: Starting out with C++ Early Objects, 7th edition; Gaddis
*
* (c) Copyright Rodrigo Escobar 2012 All rights reserved.
* 
* Description:
* A program that reads in three integers and determines and prints 
* the smallest number numerically in the group. 
* The values are NOT necessarily entered in numeric order. 
*/

#include <iostream>
using namespace std;

int main()
{

	int iFirstNumber, iSecondNumber, iThirdNumber, iSmallestNumber; 

	// INPUT : Will prompt the user to enter 3 variables
	cout << "Please enter three numbers separated by space, then press enter: \n"; 
	cin >> iFirstNumber >> iSecondNumber >> iThirdNumber;
	// This will check if the first number is bigger than the second number.
	// If true, the value of the second number will be assigned to the "iSmallestNumber" integer.
	if (iFirstNumber > iSecondNumber) {
		iSmallestNumber = iSecondNumber;
	}
	// This will check if the second number is bigger than the third number.
	// If true, the value of the third number will be assigned to the "iSmallestNumber" integer.
	if (iSecondNumber > iThirdNumber) {
		iSmallestNumber = iThirdNumber;
	}
	// If the previous step is false, will check if the third number is bigger than the first number.
	// If true, the value of the first number will be assigned to the "iSmallestNumber" integer.
	else if (iThirdNumber > iFirstNumber) {
		iSmallestNumber = iFirstNumber;
	}
	// If none of the above is true, we can assume the third number is the smallest
	// The value of the third number will be assinged to the "iSmallestNumber" integer.
	else {
		iSmallestNumber = iThirdNumber;
	}
	// OUTPUT, will tell the user the smallest number out of the three entered.
	cout << "The smallest value among " << iFirstNumber << " , " << iSecondNumber <<  " and "
		<< iThirdNumber << " is " << iSmallestNumber << endl;
	return 0 ;
}


