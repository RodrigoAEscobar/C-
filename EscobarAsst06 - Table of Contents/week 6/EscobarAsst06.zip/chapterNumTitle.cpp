#include <iostream>
#include <string>
using namespace std;

// Chapter Function
void chapterNumTitle(string sNum, string sName, string sPage) {
	int iLineLength, i, j;
	cout << "Chapter" << " " << sNum  << ":  " << sName << " ";
	j = sPage.size();
	if (j > 999) {
		j = 4;
	}
	if (j > 99) {
		j = 3;
	}
	if (j > 9) {
		j = 2;
	} else 
		j = 1;
	string sOutputLine = "Chapter" + sNum  + ":  " + sName + " ";
	iLineLength = sOutputLine.size();
	for (i = (iLineLength + 3); i <= 62 - (j * 2); i++) {
		cout << "." ;
	}
	cout << " " << sPage << endl;
}
